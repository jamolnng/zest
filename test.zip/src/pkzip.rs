#![allow(dead_code)]
#![allow(unused_variables)]

use std::collections::HashMap;
use std::convert::TryInto;
use std::fs::File;
use std::io;
use std::io::prelude::*;
use std::mem::size_of;
use std::path::Path;

#[derive(Debug, Clone)]
pub struct Error {
  kind: ErrorKind,
}

#[derive(Debug, Clone)]
pub enum ErrorKind {
  IO(std::io::ErrorKind),
  FromUtf8Error,
  Other,
}

pub enum Compression {
  Uncompressed,
}

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug)]
pub struct ZipArchive<R: Read + io::Seek> {
  reader: R,
  files: Vec<ZipFile>,
  names: HashMap<String, usize>,
}

#[derive(Debug)]
pub struct ZipFile {
  inner: ZipLocalFileHeader,
}

#[derive(Debug, Copy, Clone)]
struct ZipLocalFileHeader {
  signature: u32,
  min_extract_ver: u16,
  general_purpose_flag: u16,
  compression_method: u16,
  last_mod_time: u16,
  last_mod_date: u16,
  crc32: u32,
  compressed_size: u32,
  uncompressed_size: u32,
  file_name_len: u16,
  extra_field_len: u16,
}

#[derive(Debug, Copy, Clone)]
struct ZipCentralDirectory {
  signature: u32,
  made_by_ver: u16,
  min_extract_ver: u16,
  general_purpose_flag: u16,
  compression_method: u16,
  last_mod_time: u16,
  last_mod_date: u16,
  crc32: u32,
  compressed_size: u32,
  uncompressed_size: u32,
  file_name_len: u16,
  extra_field_len: u16,
  comment_len: u16,
  start_disk: u16,
  internal_attrib: u16,
  external_attrib: u32,
  relative_offset_of_local_header: u32,
}

#[derive(Debug, Clone, Default)]
struct ZipEndOfCentralDirectory {
  signature: u32,
  disk_number: u16,
  start_disk: u16,
  num_disk_entries: u16,
  num_entries: u16,
  central_dir_size: u32,
  cendral_dir_offset: u32,
  comment_size: u16,
  comment: String,
}

impl Error {
  pub fn kind(&self) -> &ErrorKind {
    &self.kind
  }
}

impl From<std::io::Error> for Error {
  fn from(error: std::io::Error) -> Self {
    Error {
      kind: ErrorKind::IO(error.kind()),
    }
  }
}

impl From<std::string::FromUtf8Error> for Error {
  fn from(error: std::string::FromUtf8Error) -> Self {
    Error {
      kind: ErrorKind::FromUtf8Error,
    }
  }
}

impl<R: Read + io::Seek> ZipArchive<R> {
  pub fn new(mut reader: R) -> Result<ZipArchive<R>> {
    let eocd = ZipEndOfCentralDirectory::find(&mut reader)?;
    let files = vec![];
    let names = HashMap::new();
    Ok(ZipArchive {
      reader: reader,
      files: files,
      names: names,
    })
  }

  pub fn files(&self) -> &Vec<ZipFile> {
    &self.files
  }
}

impl ZipArchive<File> {
  pub fn open<P: AsRef<Path>>(path: P) -> Result<ZipArchive<File>> {
    match File::open(path) {
      Ok(file) => Self::new(file),
      _ => Err(Error {
        kind: ErrorKind::Other,
      }),
    }
  }
}

const BUF_SIZE: u64 = 65536;
const LOCAL_FILE_HEADER_SIGNATURE: u32 = 0x04034b50;
const CENTRAL_DIRECTORY_SIGNATURE: u32 = 0x02014b50;
const END_OF_CENTRAL_DIRECTORY_SIGNATURE: u32 = 0x06054b50;

impl ZipEndOfCentralDirectory {
  fn find<R: Read + io::Seek>(reader: &mut R) -> Result<ZipEndOfCentralDirectory> {
    let fsize = reader.seek(io::SeekFrom::End(0))?;
    if fsize < size_of::<ZipEndOfCentralDirectory>() as u64 {
      return Err(Error {
        kind: ErrorKind::Other,
      });
    }

    // look for the end of central directory data
    let nbytes = if fsize < BUF_SIZE { fsize } else { BUF_SIZE };
    reader.seek(io::SeekFrom::Start(fsize - nbytes))?;
    let mut buf = vec![0u8; nbytes as usize];
    reader.read(&mut buf)?;

    // find end of central directory location
    let eocd_pos = match buf.windows(4).rev().position(|window| {
      use std::convert::TryFrom;
      let array = <[u8; 4]>::try_from(window).unwrap();
      u32::from_le_bytes(array) == END_OF_CENTRAL_DIRECTORY_SIGNATURE
    }) {
      Some(i) => i + 4,
      None => {
        return Err(Error {
          kind: ErrorKind::Other,
        })
      }
    };
    let start = nbytes as usize - eocd_pos;
    let mut bytes = &buf[start..start + size_of::<ZipEndOfCentralDirectory>()];

    let signature = read_le_u32(&mut bytes);
    let disk_number = read_le_u16(&mut bytes);
    let start_disk = read_le_u16(&mut bytes);
    let num_disk_entries = read_le_u16(&mut bytes);
    let num_entries = read_le_u16(&mut bytes);
    let central_dir_size = read_le_u32(&mut bytes);
    let cendral_dir_offset = read_le_u32(&mut bytes);
    let comment_size = read_le_u16(&mut bytes);
    let start = start + size_of::<ZipEndOfCentralDirectory>();
    let comment = String::from_utf8(buf[start..start + comment_size as usize].to_vec())?;

    Ok(ZipEndOfCentralDirectory {
      signature: signature,
      disk_number: disk_number,
      start_disk: start_disk,
      num_disk_entries: num_disk_entries,
      num_entries: num_entries,
      central_dir_size: central_dir_size,
      cendral_dir_offset: cendral_dir_offset,
      comment_size: comment_size,
      comment: comment,
    })
  }
}

fn read_le_u16(input: &mut &[u8]) -> u16 {
  let (int_bytes, rest) = input.split_at(size_of::<u16>());
  *input = rest;
  u16::from_le_bytes(int_bytes.try_into().unwrap())
}

fn read_le_u32(input: &mut &[u8]) -> u32 {
  let (int_bytes, rest) = input.split_at(size_of::<u32>());
  *input = rest;
  u32::from_le_bytes(int_bytes.try_into().unwrap())
}

fn read_le_u64(input: &mut &[u8]) -> u64 {
  let (int_bytes, rest) = input.split_at(size_of::<u64>());
  *input = rest;
  u64::from_le_bytes(int_bytes.try_into().unwrap())
}
